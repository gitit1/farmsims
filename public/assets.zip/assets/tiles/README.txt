Tile sprites (PNG)

Size: 96x48 px
Anchor: centered on the diamond (tile origin is the center of the image).

Guidelines:
- Transparent background.
- Keep the diamond centered on the canvas.
- Overlays (ex: farm watered overlay) should be 96x48 and aligned to the same center.
