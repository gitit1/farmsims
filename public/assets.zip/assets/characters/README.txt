Character and prop sprites (PNG)

Recommended size: 96x128 px (can be larger if needed).
Anchor: feet at bottom-center of the image.

Guidelines:
- Transparent background.
- Align the feet to the bottom center so the sprite stands on the tile center.
- Examples: char.player.idle, prop.shopkeeper.
